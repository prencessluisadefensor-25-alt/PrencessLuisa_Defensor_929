import 'package:flutter/material.dart';
import 'package:widgets/components/globalappbar_component.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NewsFeedScreenState();
}

class _NewsFeedScreenState extends State<NotificationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: GlobalappbarComponent(),

      body: Center(
        child: Text("Notification Screen") ,
        ),
    );
  }
}